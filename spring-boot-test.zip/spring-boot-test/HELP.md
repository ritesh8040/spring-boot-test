# Getting Started


1. main class -> test.pp.springboottest/SpringBootTestApplication.java

Rest url -> 
http://localhost:8080/